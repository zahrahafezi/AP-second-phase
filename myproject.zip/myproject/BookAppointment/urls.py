from django.urls import path
from . import views

urlpatterns = [
    path('patient_home/', views.patient_home, name='login_home'),
    path('staff_home/', views.staff_home, name='staff_home'),
]